These functions are necessary to convert png to gif in Matlab R2008a.
In R2011 they are already a part of the Matlab basic module.



If you cannot produce animated gif and you obtain the following error:

??? Undefined function or method 'cq' for
input arguments of type 'uint8'.

Error in ==> rgb2ind at 91
        [map,X] = cq(RGB,m);

Error in ==> rotating_3d_globe at 590
         [imind,cm] =
         rgb2ind(img,256,'dither');


you can try to compile the functions cq() and ditherc() using your Matlab installation.
Change to this directory, where the source files cq.c and ditherc.c are located, and type:
mex cq.c
A binary file should be produced, no error message given by Matlab.
In case of failure, try changing the compiler by typing: mex -setup
and then compile again.
To compile ditherc you must type:
mex ditherc.c invcmap.c 
