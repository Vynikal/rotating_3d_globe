/* Copyright 1993-2008 The MathWorks, Inc. */

/* $Revision: 1.1.6.1 $  $Date: 2008/10/26 14:29:09 $  $Author: batserve $ */

void
inv_cmap_2( mwSize colors, int32_T *colormap, uint32_T qm, uint32_T qe, 
            uint32_T *dist_buf, int32_T *rgbmap );
